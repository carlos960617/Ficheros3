package EjerciciosClase.ejsClase1.ej3;

import java.io.File;

public class Archivo3 {

    public static void main(String[] args) {

        File f1 = new File("archivoABorrar");





    }
}
